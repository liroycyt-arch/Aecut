//! The AE Cut creator pack: 36 ready-to-use effects for edits, beats and social video.
//!
//! Every effect is real image processing (warps, blurs, channel splits, glows, frame fetching),
//! comes with ready-made default values and exposes each setting as a slider with the range
//! shown in Effect Controls. Effects that play "a hit" (shakes, punches, flashes) run from a
//! `Start Time` for their `Duration` and leave the layer untouched outside that window, so the
//! user places them on the beat by moving the start time or keyframing it.

use std::f64::consts::{PI, TAU};

use effectcraft_keyframe::Value;
use effectcraft_project::ParamUi;
use effectcraft_raster::{Image, Px, directional_blur, gaussian_blur, radial_blur};
use rayon::prelude::*;

use crate::util::{Plane, gen_image, hash1, map_xy, remap};
use crate::{Buf, EffectCtx, EffectSpec, ParamSpec, col, num, p, popup, slider};

const CAM: &str = "Camera & Motion";
const GLITCH: &str = "Glitch & Distortion";
const LIGHT: &str = "Light & Glow";
const SPEED: &str = "Speed & Time";
const TYPO: &str = "Text & Typography";
const COLOR: &str = "Color & Image";
const BEAT: &str = "Beat & Transition";

fn spec(id: &'static str, name: &'static str, category: &'static str, params: Vec<ParamSpec>, render: crate::RenderFn) -> EffectSpec {
    EffectSpec { id, name, category, params, render, gpu: false, float: true }
}

/// A slider parameter: default `d`, hard range `lo..=hi`.
fn s(id: &'static str, label: &'static str, d: f64, lo: f64, hi: f64, decimals: u8) -> ParamSpec {
    p(id, label, num(d), slider(lo, hi, lo, hi, decimals))
}

/// "When does the hit happen" (seconds of layer time).
fn start() -> ParamSpec {
    p("start", "Start Time (sec)", num(0.0), slider(0.0, 3600.0, 0.0, 10.0, 2))
}

fn bpm(d: f64) -> ParamSpec {
    s("bpm", "BPM", d, 40.0, 240.0, 0)
}

// ---------------------------------------------------------------- shared maths

fn smooth(x: f64) -> f64 {
    let x = x.clamp(0.0, 1.0);
    x * x * (3.0 - 2.0 * x)
}

fn ease_out(x: f64) -> f64 {
    1.0 - (1.0 - x.clamp(0.0, 1.0)).powi(3)
}

/// Progress 0..1 through the effect's window, `None` outside it.
fn window(ctx: &EffectCtx, duration: f64) -> Option<f64> {
    let t = ctx.time - ctx.params.f("start");
    if duration <= 0.0 || t < 0.0 || t > duration { None } else { Some(t / duration) }
}

fn frame_of(ctx: &EffectCtx) -> u32 {
    (ctx.time * ctx.fps()).floor() as i64 as u32
}

/// Smooth random value in -1..1 that changes `rate` times a second.
fn wobble(t: f64, rate: f64, k: u32, seed: u32) -> f64 {
    let x = t * rate;
    let i = x.floor();
    let f = smooth(x - i);
    let a = hash1(i as i64 as u32, k, seed) as f64 * 2.0 - 1.0;
    let b = hash1((i + 1.0) as i64 as u32, k, seed) as f64 * 2.0 - 1.0;
    a + (b - a) * f
}

fn centre(img: &Image) -> (f64, f64) {
    (img.width as f64 / 2.0, img.height as f64 / 2.0)
}

/// Move by (`dx`, `dy`) pixels, rotate by `rot` degrees and zoom about the middle of the image;
/// the edges are repeated so a shake never shows a transparent border.
fn xform(img: &Image, dx: f64, dy: f64, rot: f64, zoom: f64) -> Image {
    let (cx, cy) = centre(img);
    let (sn, cs) = rot.to_radians().sin_cos();
    let z = 1.0 / zoom.max(1e-3);
    remap(img, true, move |x, y| {
        let (px, py) = (x - cx - dx, y - cy - dy);
        Some((cx + (px * cs + py * sn) * z, cy + (-px * sn + py * cs) * z))
    })
}

/// Red goes one way, blue the other (pixels), green stays.
fn rgb_split(img: &Image, dx: f64, dy: f64) -> Image {
    if dx.abs() < 0.01 && dy.abs() < 0.01 {
        return img.clone();
    }
    gen_image(img.width, img.height, |x, y| {
        let (fx, fy) = (x as f64 + 0.5, y as f64 + 0.5);
        let r = img.sample_bilinear(fx - dx, fy - dy);
        let g = img.get(x as i64, y as i64);
        let b = img.sample_bilinear(fx + dx, fy + dy);
        [r[0], g[1], b[2], r[3].max(g[3]).max(b[3])]
    })
}

/// Horizontal slices pushed sideways by up to `amount` pixels; `density` (0..1) of them move.
fn slice_glitch(img: &Image, amount: f64, density: f64, frame: u32, seed: u32) -> Image {
    let band = (img.height / 36).max(2) as usize;
    gen_image(img.width, img.height, |x, y| {
        let id = (y / band) as u32;
        let r = hash1(id, frame, seed) as f64;
        let off = if r < density { (hash1(id, frame.wrapping_add(91), seed) as f64 - 0.5) * 2.0 * amount } else { 0.0 };
        img.sample_bilinear_clamped(x as f64 + 0.5 - off, y as f64 + 0.5)
    })
}

/// Add `amount` of white light (scaled by the pixel's own alpha).
fn flash(img: &mut Image, amount: f32, tint: [f32; 3]) {
    if amount <= 0.0 {
        return;
    }
    map_xy(img, |_, _, mut px| {
        for c in 0..3 {
            px[c] += amount * tint[c] * px[3];
        }
        px
    });
}

fn over(top: Px, bottom: Px) -> Px {
    let ia = 1.0 - top[3];
    [top[0] + bottom[0] * ia, top[1] + bottom[1] * ia, top[2] + bottom[2] * ia, top[3] + bottom[3] * ia]
}

fn add_px(a: Px, b: Px) -> Px {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2], (a[3] + b[3]).min(1.0)]
}

fn scale_px(a: Px, k: f32) -> Px {
    [a[0] * k, a[1] * k, a[2] * k, a[3] * k]
}

/// `img` plus `glow` (both premultiplied), the glow behind the image.
fn glow_behind(img: &Image, glow: &Image) -> Image {
    let mut out = img.clone();
    out.data.par_iter_mut().zip(glow.data.par_iter()).for_each(|(o, g)| *o = over(*o, *g));
    out
}

fn tint(img: &Image, c: [f32; 3], gain: f32) -> Image {
    let mut out = img.clone();
    map_xy(&mut out, |_, _, px| {
        let a = px[3] * gain;
        [c[0] * a, c[1] * a, c[2] * a, a.min(1.0)]
    });
    out
}

fn mix_images(a: &Image, b: &Image, t: f32) -> Image {
    let mut out = a.clone();
    out.data.par_iter_mut().zip(b.data.par_iter()).for_each(|(o, q)| {
        for c in 0..4 {
            o[c] += (q[c] - o[c]) * t;
        }
    });
    out
}

fn keep(mut b: Buf, img: Image) -> Buf {
    b.img = img;
    b
}

// ---------------------------------------------------------------- 1. Camera & Motion

fn impact_shake(ctx: &EffectCtx, b: Buf) -> Buf {
    let dur = ctx.params.f("duration");
    let Some(u) = window(ctx, dur) else { return b };
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let rate = ctx.params.f("speed").clamp(1.0, 40.0);
    let decay = (1.0 - u).powi(2);
    let amp = k * decay * b.img.width.min(b.img.height) as f64 * 0.07;
    let t = ctx.time;
    let (dx, dy) = (wobble(t, rate, 1, ctx.seed) * amp, wobble(t, rate, 2, ctx.seed) * amp);
    let rot = wobble(t, rate, 3, ctx.seed) * k * decay * 3.0;
    let zoom = 1.0 + k * decay * 0.06;
    let img = xform(&b.img, dx, dy, rot, zoom);
    keep(b, img)
}

fn chaos_shake(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let zoom = (ctx.params.f("zoom") / 100.0).clamp(1.0, 1.5);
    let chaos = (ctx.params.f("randomness") / 100.0).clamp(0.0, 1.0);
    let t = ctx.time;
    let fps = ctx.fps();
    let mix = |k1: u32| {
        let smooth_part = wobble(t, 6.0, k1, ctx.seed);
        let rough = hash1(frame_of(ctx), k1, ctx.seed) as f64 * 2.0 - 1.0;
        smooth_part + (rough - smooth_part) * chaos
    };
    let amp = k * b.img.width.min(b.img.height) as f64 * 0.05;
    let _ = fps;
    let z = 1.0 + (zoom - 1.0) * (0.5 + 0.5 * mix(4).abs());
    let img = xform(&b.img, mix(1) * amp, mix(2) * amp, mix(3) * k * 4.0, z.max(1.0 + (zoom - 1.0) * 0.5));
    keep(b, img)
}

fn smooth_drift(ctx: &EffectCtx, b: Buf) -> Buf {
    let speed = (ctx.params.f("speed") / 100.0).clamp(0.0, 1.0);
    let dist = ctx.params.f("distance") * b.scale;
    let zoom = (ctx.params.f("zoom") / 100.0).clamp(1.0, 1.5);
    let phase = ctx.time * speed * TAU * 0.2;
    let breathe = 0.5 - 0.5 * phase.cos();
    let img = xform(&b.img, dist * phase.sin(), dist * 0.5 * (phase * 0.7).cos(), phase.sin() * 0.6 * speed, 1.0 + (zoom - 1.0) * (0.6 + 0.4 * breathe));
    keep(b, img)
}

fn zoom_punch(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some(u) = window(ctx, ctx.params.f("duration")) else { return b };
    let e = (u * PI).sin();
    let z = 1.0 + (ctx.params.f("zoom") / 100.0 - 1.0) * e;
    let mut img = xform(&b.img, 0.0, 0.0, 0.0, z);
    let amount = ctx.params.f("blur") / 100.0 * 0.12 * e;
    if amount > 1e-4 {
        img = radial_blur(&img, centre(&img), amount, true);
    }
    keep(b, img)
}

fn whip_cam(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some(u) = window(ctx, ctx.params.f("duration")) else { return b };
    let speed = (ctx.params.f("speed") / 100.0).clamp(0.0, 1.0);
    let dist = ctx.params.f("distance") * b.scale;
    let settle = 1.0 - ease_out(u.powf(0.6));
    let dx = dist * settle;
    let mut img = xform(&b.img, dx, 0.0, 0.0, 1.0 + 0.04 * settle);
    // The blur follows the speed of the move: strongest at the start, gone as it lands.
    let length = dist * 0.18 * speed * settle;
    if length > 0.5 {
        img = directional_blur(&img, 90.0, length);
    }
    keep(b, img)
}

fn spin_impact(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some(u) = window(ctx, ctx.params.f("duration")) else { return b };
    let speed = (ctx.params.f("speed") / 100.0).clamp(0.0, 1.0);
    let rot = ctx.params.f("angle") * (1.0 - u).powf(1.0 + speed * 3.0);
    let zoom = 1.0 + rot.abs().to_radians() * 0.9;
    let img = xform(&b.img, 0.0, 0.0, rot, zoom);
    keep(b, img)
}

// ---------------------------------------------------------------- 2. Glitch & Distortion

fn rgb_rift(ctx: &EffectCtx, b: Buf) -> Buf {
    let flicker = (ctx.params.f("flicker") / 100.0).clamp(0.0, 1.0);
    let r = hash1(frame_of(ctx), 5, ctx.seed) as f64;
    let split = ctx.params.f("split") * b.scale * (1.0 - flicker * r);
    let img = rgb_split(&b.img, split, split * 0.25);
    keep(b, img)
}

fn digital_collapse(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let bs = (ctx.params.f("blockSize") * b.scale).max(1.0);
    let q = ((ctx.time * 12.0).floor() as i64) as u32;
    let seed = ctx.seed;
    let src = &b.img;
    let img = gen_image(src.width, src.height, |x, y| {
        let (bx, by) = ((x as f64 / bs) as u32, (y as f64 / bs) as u32);
        let r = hash1(bx, by.wrapping_add(q.wrapping_mul(131)), seed) as f64;
        if r >= k * 0.55 {
            return src.get(x as i64, y as i64);
        }
        let ox = (hash1(bx, by, q ^ 0x51) as f64 - 0.5) * bs * 4.0 * k;
        let oy = (hash1(by, bx, q ^ 0x77) as f64 - 0.5) * bs * 1.5 * k;
        let (fx, fy) = (x as f64 + 0.5 + ox, y as f64 + 0.5 + oy);
        if r < k * 0.18 {
            let s = bs * 0.5 * k;
            let (a, c) = (src.sample_bilinear_clamped(fx - s, fy), src.sample_bilinear_clamped(fx + s, fy));
            let g = src.sample_bilinear_clamped(fx, fy);
            [a[0], g[1], c[2], g[3]]
        } else {
            src.sample_bilinear_clamped(fx, fy)
        }
    });
    keep(b, img)
}

fn vhs_breakdown(ctx: &EffectCtx, b: Buf) -> Buf {
    let noise = (ctx.params.f("noise") / 100.0).clamp(0.0, 1.0) as f32;
    let warp = (ctx.params.f("distortion") / 100.0).clamp(0.0, 1.0);
    let t = ctx.time;
    let h = b.img.height as f64;
    let sc = b.scale;
    let frame = frame_of(ctx);
    let seed = ctx.seed;
    let tear_y = (t * 0.31).fract() * h;
    let src = &b.img;
    let img = gen_image(src.width, src.height, |x, y| {
        let fy = y as f64 + 0.5;
        let mut dx = warp * 6.0 * sc * (fy * 0.11 + t * 9.0).sin();
        let tear = (-((fy - tear_y) / (h * 0.035 + 1.0)).powi(2)).exp();
        dx += warp * 60.0 * sc * tear * (wobble(t, 18.0, 9, seed));
        let fx = x as f64 + 0.5 - dx;
        let chroma = 3.0 * sc * (0.4 + warp);
        let r = src.sample_bilinear_clamped(fx - chroma, fy);
        let g = src.sample_bilinear_clamped(fx, fy);
        let bl = src.sample_bilinear_clamped(fx + chroma, fy);
        let mut px = [r[0], g[1], bl[2], g[3]];
        let scan = if y % 3 == 0 { 0.9 } else { 1.0 };
        let n = (hash1(x as u32, y as u32, frame ^ seed) - 0.5) * noise * 0.6;
        for c in 0..3 {
            px[c] = (px[c] * scan + n * px[3]).max(0.0);
        }
        px
    });
    keep(b, img)
}

fn pixel_melt(ctx: &EffectCtx, b: Buf) -> Buf {
    let size = (ctx.params.f("size") * b.scale).max(1.0);
    let stretch = (ctx.params.f("stretch") / 100.0).clamp(0.0, 1.0);
    let seed = ctx.seed;
    let (w, h) = (b.img.width as f64, b.img.height as f64);
    let src = &b.img;
    let img = gen_image(src.width, src.height, |x, y| {
        let col = (x as f64 / size).floor();
        let start_y = h * (0.25 + 0.5 * hash1(col as u32, 1, seed) as f64);
        let amount = stretch * (0.25 + 0.75 * hash1(col as u32, 2, seed) as f64);
        let fy = y as f64 + 0.5;
        let sy = if fy > start_y { start_y + (fy - start_y) * (1.0 - amount * 0.95) } else { fy };
        let sx = ((col + 0.5) * size).min(w - 0.5);
        let mix = smooth((fy - start_y) / (h * 0.1 + 1.0));
        let blocky = src.sample_bilinear_clamped(sx, sy);
        let plain = src.sample_bilinear_clamped(x as f64 + 0.5, sy);
        [plain[0] + (blocky[0] - plain[0]) * mix as f32, plain[1] + (blocky[1] - plain[1]) * mix as f32, plain[2] + (blocky[2] - plain[2]) * mix as f32, plain[3] + (blocky[3] - plain[3]) * mix as f32]
    });
    keep(b, img)
}

fn glitch_surge(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some(u) = window(ctx, ctx.params.f("duration")) else { return b };
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let e = (1.0 - u).powf(1.4);
    let zoom = 1.0 + (ctx.params.f("zoom") / 100.0 - 1.0) * e;
    let w = b.img.width as f64;
    let mut img = xform(&b.img, 0.0, 0.0, 0.0, zoom);
    img = slice_glitch(&img, w * 0.12 * k * e, 0.45, frame_of(ctx), ctx.seed);
    img = rgb_split(&img, w * 0.02 * k * e, 0.0);
    flash(&mut img, (0.45 * k * e) as f32, [1.0, 1.0, 1.0]);
    keep(b, img)
}

fn signal_break(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let rate = 2.0 + ctx.params.f("speed") / 100.0 * 28.0;
    let frame = ((ctx.time * rate).floor() as i64) as u32;
    let w = b.img.width as f64;
    let mut img = slice_glitch(&b.img, w * 0.10 * k, 0.15 + 0.5 * k, frame, ctx.seed);
    img = rgb_split(&img, w * 0.008 * k, 0.0);
    let seed = ctx.seed;
    map_xy(&mut img, |x, y, mut px| {
        let line = hash1((y / 2) as u32, frame, seed ^ 0x33);
        if (line as f64) < k * 0.08 {
            let n = hash1(x as u32, y as u32, frame) * 0.9 + 0.1;
            for c in 0..3 {
                px[c] = (px[c] * 0.3 + n * px[3]).max(0.0);
            }
        }
        px
    });
    keep(b, img)
}

// ---------------------------------------------------------------- 3. Light & Glow

fn pad_for_glow(ctx: &EffectCtx, b: &mut Buf, sigma: f64) {
    if !ctx.adjustment {
        b.pad((sigma * 3.0).ceil().min(2000.0) as u32);
    }
}

fn flash_impact(ctx: &EffectCtx, b: Buf) -> Buf {
    let frames = ctx.params.f("frames").max(1.0);
    let dur = frames / ctx.fps();
    let Some(u) = window(ctx, dur) else { return b };
    let k = (ctx.params.f("intensity") / 100.0).max(0.0);
    let mut img = b.img.clone();
    flash(&mut img, (k * (1.0 - u).powi(2)) as f32, [1.0, 1.0, 1.0]);
    keep(b, img)
}

fn neon_aura(ctx: &EffectCtx, mut b: Buf) -> Buf {
    let gain = (ctx.params.f("glow") / 100.0).max(0.0) as f32;
    let sigma = ctx.params.f("radius") * b.scale * 0.5;
    if sigma <= 0.05 || gain <= 0.0 {
        return b;
    }
    pad_for_glow(ctx, &mut b, sigma);
    let c = ctx.params.color("color");
    let blurred = gaussian_blur(&b.img, sigma, sigma, false);
    let wide = gaussian_blur(&b.img, sigma * 2.2, sigma * 2.2, false);
    let glow = tint(&mix_images(&blurred, &wide, 0.4), [c[0], c[1], c[2]], gain * 2.2);
    let img = glow_behind(&b.img, &glow);
    keep(b, img)
}

fn lens_burst(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0) as f32;
    let len = (ctx.params.f("length") / 100.0).clamp(0.0, 1.0);
    let sx = len * b.img.width as f64 * 0.25;
    if sx < 0.5 || k <= 0.0 {
        return b;
    }
    let mut bright = b.img.clone();
    map_xy(&mut bright, |_, _, px| {
        let l = 0.2126 * px[0] + 0.7152 * px[1] + 0.0722 * px[2];
        let m = ((l - 0.6) / 0.4).clamp(0.0, 1.0);
        scale_px(px, m)
    });
    let streak = gaussian_blur(&bright, sx, 0.0, false);
    let core = gaussian_blur(&bright, sx * 0.08 + 1.0, sx * 0.08 + 1.0, false);
    let mut img = b.img.clone();
    img.data.par_iter_mut().zip(streak.data.par_iter().zip(core.data.par_iter())).for_each(|(o, (s, c))| {
        let add = [s[0] * 0.55 * 3.0 * k + c[0] * k, s[1] * 0.8 * 3.0 * k + c[1] * k, s[2] * 1.0 * 3.0 * k + c[2] * k, 0.0];
        *o = [o[0] + add[0], o[1] + add[1], o[2] + add[2], o[3].max((s[3] * 2.0 * k).min(1.0))];
    });
    keep(b, img)
}

fn edge_glow(ctx: &EffectCtx, mut b: Buf) -> Buf {
    let gain = (ctx.params.f("intensity") / 100.0).max(0.0) as f32;
    let sigma = ctx.params.f("radius") * b.scale * 0.5;
    if gain <= 0.0 {
        return b;
    }
    pad_for_glow(ctx, &mut b, sigma);
    let l = Plane::luma(&b.img);
    let (w, h) = (l.w as i64, l.h as i64);
    let at = |x: i64, y: i64| l.data[(y.clamp(0, h - 1) * w + x.clamp(0, w - 1)) as usize];
    let c = ctx.params.color("color");
    let edges = gen_image(b.img.width, b.img.height, |x, y| {
        let (x, y) = (x as i64, y as i64);
        let gx = at(x + 1, y - 1) + 2.0 * at(x + 1, y) + at(x + 1, y + 1) - at(x - 1, y - 1) - 2.0 * at(x - 1, y) - at(x - 1, y + 1);
        let gy = at(x - 1, y + 1) + 2.0 * at(x, y + 1) + at(x + 1, y + 1) - at(x - 1, y - 1) - 2.0 * at(x, y - 1) - at(x + 1, y - 1);
        let m = ((gx * gx + gy * gy).sqrt() * 1.5).clamp(0.0, 1.0);
        [c[0] * m, c[1] * m, c[2] * m, m]
    });
    let soft = if sigma > 0.05 { gaussian_blur(&edges, sigma, sigma, false) } else { edges.clone() };
    let mut img = b.img.clone();
    img.data.par_iter_mut().zip(soft.data.par_iter().zip(edges.data.par_iter())).for_each(|(o, (g, e))| {
        let add = add_px(scale_px(*g, gain * 2.5), scale_px(*e, gain * 0.6));
        *o = [o[0] + add[0], o[1] + add[1], o[2] + add[2], o[3].max(add[3].min(1.0))];
    });
    keep(b, img)
}

fn film_burn(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0) as f32;
    let spread = (ctx.params.f("spread") / 100.0).clamp(0.0, 1.0);
    let t = ctx.time;
    let frame = frame_of(ctx);
    let seed = ctx.seed;
    let (w, h) = (b.img.width as f64, b.img.height as f64);
    let mut img = b.img.clone();
    map_xy(&mut img, |x, y, mut px| {
        let (u, v) = (x as f64 / w, y as f64 / h);
        let a = 0.5 + 0.5 * (3.1 * u + 1.7 * t + (2.3 * v + 0.9 * t).sin() * 1.5).sin();
        let c = 0.5 + 0.5 * (4.2 * v - 1.3 * t + (1.9 * u - 0.7 * t).sin() * 1.2).sin();
        let m = smooth(((a * 0.6 + c * 0.4) - (1.0 - spread)) / (spread.max(0.05) * 0.8 + 0.05)) as f32;
        let flick = 0.9 + 0.1 * hash1(frame, 3, seed) as f32;
        let warm = [1.0, 0.42 + 0.4 * c as f32, 0.08 + 0.3 * (c as f32).powi(2)];
        for i in 0..3 {
            px[i] += warm[i] * m * k * flick * 0.9 * px[3];
        }
        px
    });
    keep(b, img)
}

fn light_sweep(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0) as f32;
    let width = (ctx.params.f("width") * b.scale).max(1.0);
    let (w, h) = (b.img.width as f64, b.img.height as f64);
    let (dx, dy) = (0.94_f64, 0.34_f64);
    let extent = w * dx + h * dy;
    let pos = -width * 2.0 + (extent + width * 4.0) * (ctx.time / 2.0).fract();
    let mut img = b.img.clone();
    map_xy(&mut img, |x, y, mut px| {
        let d = (x as f64 * dx + y as f64 * dy) - pos;
        let m = (-(d / (width * 0.5)).powi(2)).exp() as f32 * k;
        for c in 0..3 {
            px[c] += m * px[3];
        }
        px
    });
    keep(b, img)
}

// ---------------------------------------------------------------- 4. Speed & Time

/// Frames of the layer at `times` (layer time), on one grid; falls back to the current pixels.
fn frames_at(ctx: &EffectCtx, times: &[f64]) -> Option<(Buf, Vec<Image>)> {
    let fr = crate::time_fx::fetch(ctx, times)?;
    // `fetch` merges equal times, so look every wanted time up by nearest match.
    let mut out = Vec::with_capacity(times.len());
    let mut uniq: Vec<i64> = times.iter().map(|t| (t * 1e6).round() as i64).collect();
    uniq.sort_unstable();
    uniq.dedup();
    for t in times {
        let key = (t * 1e6).round() as i64;
        let i = uniq.iter().position(|&u| u == key).unwrap_or(0).min(fr.imgs.len().saturating_sub(1));
        out.push(fr.imgs[i].clone());
    }
    Some((fr.grid, out))
}

fn with_grid(grid: Buf, img: Image) -> Buf {
    Buf { img, offset: grid.offset, scale: grid.scale }
}

/// Where the layer's own clock stands at time `t` while it ramps from `v0` to `v1` times speed.
fn rushed_time(t: f64, v0: f64, v1: f64, ramp: f64) -> f64 {
    let n = 48;
    let mut acc = 0.0;
    let dt = t.max(0.0) / n as f64;
    for i in 0..n {
        let mid = (i as f64 + 0.5) * dt;
        acc += (v0 + (v1 - v0) * smooth(mid / ramp)) * dt;
    }
    acc
}

fn velocity_rush(ctx: &EffectCtx, b: Buf) -> Buf {
    if ctx.time < ctx.params.f("start") {
        return b;
    }
    let v0 = ctx.params.f("startSpeed").max(0.01);
    let v1 = ctx.params.f("peakSpeed").max(0.01);
    let blur = (ctx.params.f("blur") / 100.0).clamp(0.0, 1.0);
    let ramp = ctx.params.f("rampTime").max(0.1);
    let t = (ctx.time - ctx.params.f("start")).max(0.0);
    let tau = rushed_time(t, v0, v1, ramp);
    let v_now = v0 + (v1 - v0) * smooth(t / ramp);
    let samples = 1 + (blur * 5.0).round() as usize;
    let span = v_now / ctx.fps() * 0.5 * blur;
    let times: Vec<f64> = (0..samples).map(|i| (tau + ctx.params.f("start") - span * i as f64 / samples as f64).max(0.0)).collect();
    let Some((grid, imgs)) = frames_at(ctx, &times) else { return b };
    let mut acc = Image::new(grid.img.width, grid.img.height);
    for im in &imgs {
        acc.data.par_iter_mut().zip(im.data.par_iter()).for_each(|(o, q)| *o = add_px_unclamped(*o, scale_px(*q, 1.0 / samples as f32)));
    }
    with_grid(grid, acc)
}

fn add_px_unclamped(a: Px, b: Px) -> Px {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3]]
}

/// Current frame over `count` older frames `step` seconds apart, each fainter than the last.
fn trail(ctx: &EffectCtx, b: Buf, count: usize, step: f64, opacity: f32, screen: bool) -> Buf {
    let times: Vec<f64> = (0..=count).map(|i| (ctx.time - i as f64 * step).max(0.0)).collect();
    let Some((grid, imgs)) = frames_at(ctx, &times) else { return b };
    let mut out = imgs[0].clone();
    for (i, im) in imgs.iter().enumerate().skip(1) {
        let w = opacity * (1.0 - (i as f32 - 1.0) / (count as f32 + 1.0));
        out.data.par_iter_mut().zip(im.data.par_iter()).for_each(|(o, q)| {
            let q = scale_px(*q, w);
            *o = if screen { [o[0] + q[0] - o[0] * q[0], o[1] + q[1] - o[1] * q[1], o[2] + q[2] - o[2] * q[2], o[3] + q[3] * (1.0 - o[3])] } else { over(*o, q) };
        });
    }
    with_grid(grid, out)
}

fn time_echo(ctx: &EffectCtx, b: Buf) -> Buf {
    let n = ctx.params.f("layers").round().clamp(1.0, 20.0) as usize;
    let op = (ctx.params.f("opacity") / 100.0).clamp(0.0, 1.0) as f32;
    trail(ctx, b, n, 2.0 / ctx.fps(), op, false)
}

fn motion_trails(ctx: &EffectCtx, b: Buf) -> Buf {
    let n = ctx.params.f("length").round().clamp(1.0, 30.0) as usize;
    let op = (ctx.params.f("opacity") / 100.0).clamp(0.0, 1.0) as f32;
    trail(ctx, b, n, 1.0 / ctx.fps(), op, true)
}

fn hyper_drive(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some(u) = window(ctx, ctx.params.f("duration")) else { return b };
    let e = (u * PI).sin();
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let mut img = xform(&b.img, 0.0, 0.0, 0.0, 1.0 + 0.12 * k * e);
    let amount = k * 0.2 * e;
    if amount > 1e-4 {
        img = radial_blur(&img, centre(&img), amount, true);
    }
    keep(b, img)
}

fn freeze_pop(ctx: &EffectCtx, b: Buf) -> Buf {
    let begin = ctx.params.f("start");
    let dur = ctx.params.f("duration");
    let t = ctx.time - begin;
    if t < 0.0 || t > dur || dur <= 0.0 {
        return b;
    }
    // Hold the frame at the start time, pop it up and sharpen it.
    let Some((grid, imgs)) = frames_at(ctx, &[begin]) else { return b };
    let u = t / dur;
    let zoom = 1.0 + (ctx.params.f("zoom") / 100.0 - 1.0) * ease_out((u * 4.0).min(1.0));
    let mut img = xform(&imgs[0], 0.0, 0.0, 0.0, zoom);
    let k = (ctx.params.f("sharpen") / 100.0).clamp(0.0, 1.0) as f32;
    if k > 0.0 {
        img = unsharp(&img, 1.5 * grid.scale, k * 2.0);
    }
    with_grid(grid, img)
}

fn unsharp(img: &Image, sigma: f64, amount: f32) -> Image {
    let blurred = gaussian_blur(img, sigma, sigma, true);
    let mut out = img.clone();
    out.data.par_iter_mut().zip(blurred.data.par_iter()).for_each(|(o, bl)| {
        for c in 0..3 {
            o[c] = (o[c] + (o[c] - bl[c]) * amount).max(0.0).min(o[3].max(1.0) * 4.0);
        }
    });
    out
}

// ---------------------------------------------------------------- 5. Text & Typography

fn kinetic_punch(ctx: &EffectCtx, b: Buf) -> Buf {
    let dur = ctx.params.f("duration").max(0.01);
    let t = ctx.time - ctx.params.f("start");
    if t < 0.0 {
        return keep(b.clone(), Image::new(b.img.width, b.img.height));
    }
    if t > dur {
        return b;
    }
    let u = t / dur;
    let peak = (ctx.params.f("peak") / 100.0).max(1.0);
    let sc = if u < 0.6 { 0.35 + (peak - 0.35) * ease_out(u / 0.6) } else { peak + (1.0 - peak) * smooth((u - 0.6) / 0.4) };
    let fade = (u * 4.0).min(1.0) as f32;
    let mut img = xform_plain(&b.img, sc);
    img.data.par_iter_mut().for_each(|px| *px = scale_px(*px, fade));
    keep(b, img)
}

/// Zoom about the middle without repeating edges (text keeps its transparent surroundings).
fn xform_plain(img: &Image, zoom: f64) -> Image {
    let (cx, cy) = centre(img);
    let z = 1.0 / zoom.max(1e-3);
    remap(img, false, move |x, y| Some((cx + (x - cx) * z, cy + (y - cy) * z)))
}

/// Column runs of ink (the words of one line of text): (first column, last column).
fn word_spans(img: &Image) -> Vec<(usize, usize)> {
    let (w, h) = (img.width as usize, img.height as usize);
    let mut col_ink = vec![false; w];
    let (mut y0, mut y1) = (h, 0usize);
    for y in 0..h {
        for x in 0..w {
            if img.data[y * w + x][3] > 0.08 {
                col_ink[x] = true;
                y0 = y0.min(y);
                y1 = y1.max(y);
            }
        }
    }
    if y1 < y0 {
        return vec![];
    }
    let gap = (((y1 - y0) as f64) * 0.28).max(4.0) as usize;
    let mut spans: Vec<(usize, usize)> = Vec::new();
    let mut x = 0;
    while x < w {
        if col_ink[x] {
            let a = x;
            let mut last = x;
            while x < w && (col_ink[x] || x - last <= gap) {
                if col_ink[x] {
                    last = x;
                }
                x += 1;
            }
            spans.push((a, last));
        } else {
            x += 1;
        }
    }
    spans
}

fn word_spotlight(ctx: &EffectCtx, b: Buf) -> Buf {
    let spans = word_spans(&b.img);
    if spans.is_empty() {
        return b;
    }
    let per = ctx.params.f("wordTime").max(0.05);
    let idx = ((ctx.time / per).floor() as i64).rem_euclid(spans.len() as i64) as usize;
    let (x0, x1) = spans[idx];
    let sc = (ctx.params.f("scale") / 100.0).max(1.0);
    let c = ctx.params.color("color");
    let local = ((ctx.time / per).fract()).clamp(0.0, 1.0);
    let pop = 1.0 + (sc - 1.0) * smooth((local * 4.0).min(1.0));
    let src = &b.img;
    let cxw = (x0 + x1) as f64 / 2.0 + 0.5;
    let cyw = src.height as f64 / 2.0;
    let img = gen_image(src.width, src.height, |x, y| {
        let base = if x >= x0 && x <= x1 { [0.0; 4] } else { src.get(x as i64, y as i64) };
        let (fx, fy) = (x as f64 + 0.5, y as f64 + 0.5);
        let (sx, sy) = (cxw + (fx - cxw) / pop, cyw + (fy - cyw) / pop);
        if sx < x0 as f64 || sx > (x1 + 1) as f64 {
            return base;
        }
        let q = src.sample_bilinear(sx, sy);
        let a = q[3];
        let top = if a > 1e-5 {
            let l = (0.2126 * q[0] + 0.7152 * q[1] + 0.0722 * q[2]) / a;
            let m = 0.85_f32;
            [(q[0] / a * (1.0 - m) + c[0] * m * (0.6 + 0.4 * l)) * a, (q[1] / a * (1.0 - m) + c[1] * m * (0.6 + 0.4 * l)) * a, (q[2] / a * (1.0 - m) + c[2] * m * (0.6 + 0.4 * l)) * a, a]
        } else {
            q
        };
        over(top, base)
    });
    keep(b, img)
}

fn holo_type(ctx: &EffectCtx, mut b: Buf) -> Buf {
    let gain = (ctx.params.f("glow") / 100.0).max(0.0) as f32;
    let split = ctx.params.f("split") * b.scale;
    let sigma = (6.0 * b.scale).max(1.0);
    pad_for_glow(ctx, &mut b, sigma);
    let t = ctx.time;
    let mut base = rgb_split(&b.img, split, 0.0);
    let flick = 0.92 + 0.08 * (t * 37.0).sin() as f32;
    map_xy(&mut base, |_, y, mut px| {
        let scan = if y % 4 < 2 { 1.0 } else { 0.8 };
        for c in 0..3 {
            px[c] *= scan * flick;
        }
        px
    });
    let glow = tint(&gaussian_blur(&b.img, sigma, sigma, false), [0.35, 0.9, 1.0], gain * 2.0);
    let img = glow_behind(&base, &glow);
    keep(b, img)
}

fn light_reveal(ctx: &EffectCtx, b: Buf) -> Buf {
    let dur = ctx.params.f("duration").max(0.01);
    let t = ctx.time - ctx.params.f("start");
    if t > dur {
        return b;
    }
    let glow = (ctx.params.f("glow") / 100.0).clamp(0.0, 1.0) as f32;
    let w = b.img.width as f64;
    let u = (t / dur).clamp(0.0, 1.0);
    let pos = -0.1 * w + 1.2 * w * ease_out(u);
    let bar = (w * 0.04).max(2.0);
    let mut img = b.img.clone();
    map_xy(&mut img, |x, _, px| {
        let d = x as f64 + 0.5 - pos;
        let reveal = smooth(1.0 - d / bar) as f32;
        let edge = (-(d / bar).powi(2)).exp() as f32 * glow;
        let a = px[3] * reveal;
        let mut o = scale_px(px, reveal);
        for c in 0..3 {
            o[c] += edge * a * 1.5;
        }
        o
    });
    keep(b, img)
}

// ---------------------------------------------------------------- 6. Color & Image

fn color_surge(ctx: &EffectCtx, b: Buf) -> Buf {
    let sat = (ctx.params.f("saturation") / 100.0).max(0.0) as f32;
    let con = 1.0 + (ctx.params.f("contrast") / 100.0) as f32;
    let mut img = b.img.clone();
    map_xy(&mut img, |_, _, px| {
        let a = px[3];
        if a <= 1e-6 {
            return px;
        }
        let mut c = [px[0] / a, px[1] / a, px[2] / a];
        let l = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
        for v in c.iter_mut() {
            *v = (l + (*v - l) * sat - 0.5) * con + 0.5;
            *v = v.max(0.0);
        }
        [c[0] * a, c[1] * a, c[2] * a, a]
    });
    keep(b, img)
}

fn cinema_focus(ctx: &EffectCtx, b: Buf) -> Buf {
    let dark = (ctx.params.f("vignette") / 100.0).clamp(0.0, 1.0);
    let grain = (ctx.params.f("grain") / 100.0).clamp(0.0, 1.0) as f32;
    let (w, h) = (b.img.width as f64, b.img.height as f64);
    let frame = frame_of(ctx);
    let seed = ctx.seed;
    let mut img = b.img.clone();
    map_xy(&mut img, |x, y, mut px| {
        let (nx, ny) = ((x as f64 + 0.5) / w * 2.0 - 1.0, (y as f64 + 0.5) / h * 2.0 - 1.0);
        let r = (nx * nx + ny * ny).sqrt() / 1.4142;
        let v = 1.0 - dark * smooth((r - 0.35) / 0.65);
        let n = (hash1(x as u32, y as u32, frame ^ seed) - 0.5) * grain * 0.35;
        for c in 0..3 {
            px[c] = (px[c] * v as f32 + n * px[3]).max(0.0);
        }
        px
    });
    keep(b, img)
}

fn clean_sharpen(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0) as f32;
    let sigma = ctx.params.f("radius") * b.scale;
    if k <= 0.0 || sigma < 0.05 {
        return b;
    }
    let img = unsharp(&b.img, sigma, k * 2.5);
    keep(b, img)
}

fn fisheye_pro(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("strength") / 100.0).clamp(0.0, 1.0) * 0.9;
    let sc = (ctx.params.f("scale") / 100.0).max(0.1);
    let (cx, cy) = centre(&b.img);
    let half = (cx * cx + cy * cy).sqrt();
    let img = remap(&b.img, true, move |x, y| {
        let (dx, dy) = ((x - cx) / sc, (y - cy) / sc);
        let r = (dx * dx + dy * dy).sqrt() / half;
        let f = 1.0 + k * r * r;
        Some((cx + dx * f, cy + dy * f))
    });
    keep(b, img)
}

fn cinematic_blur(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0) as f32;
    let sigma = ctx.params.f("radius") * b.scale * 0.5;
    if k <= 0.0 || sigma < 0.05 {
        return b;
    }
    let blurred = gaussian_blur(&b.img, sigma, sigma, true);
    let (w, h) = (b.img.width as f64, b.img.height as f64);
    let mut img = b.img.clone();
    img.data.par_iter_mut().zip(blurred.data.par_iter()).enumerate().for_each(|(i, (o, bl))| {
        let (x, y) = ((i % b.img.width as usize) as f64, (i / b.img.width as usize) as f64);
        let (nx, ny) = (x / w * 2.0 - 1.0, y / h * 2.0 - 1.0);
        let r = ((nx * nx + ny * ny).sqrt() / 1.4142) as f32;
        let m = (k * (0.35 + 0.65 * r)).clamp(0.0, 1.0);
        for c in 0..4 {
            o[c] += (bl[c] - o[c]) * m;
        }
    });
    keep(b, img)
}

// ---------------------------------------------------------------- 7. Beat & Transition

fn beat_phase(ctx: &EffectCtx) -> f64 {
    (ctx.time * ctx.params.f("bpm").max(1.0) / 60.0).fract()
}

fn rgb_pulse(ctx: &EffectCtx, b: Buf) -> Buf {
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let env = (1.0 - beat_phase(ctx)).powi(3);
    let split = k * env * b.img.width as f64 * 0.03;
    let img = rgb_split(&b.img, split, 0.0);
    keep(b, img)
}

fn beat_bounce(ctx: &EffectCtx, b: Buf) -> Buf {
    let sens = (ctx.params.f("sensitivity") / 100.0).clamp(0.0, 1.0);
    let env = (1.0 - beat_phase(ctx)).powf(1.0 + sens * 8.0);
    let zoom = 1.0 + (ctx.params.f("scale") / 100.0 - 1.0) * env;
    let img = xform(&b.img, 0.0, 0.0, 0.0, zoom);
    keep(b, img)
}

/// 0 = In (the layer arrives), 1 = Out (the layer leaves).
fn transition_progress(ctx: &EffectCtx) -> Option<(f64, bool)> {
    let out = ctx.params.e("direction") == 1;
    let dur = ctx.params.f("duration").max(0.01);
    let t = ctx.time - ctx.params.f("start");
    if t < 0.0 {
        return if out { None } else { Some((0.0, false)) };
    }
    if t > dur {
        return if out { Some((1.0, true)) } else { None };
    }
    Some((t / dur, out))
}

fn shake_transition(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some((u, out)) = transition_progress(ctx) else { return b };
    // Energy is highest where the layer is least there: the end of an Out, the start of an In.
    let e = if out { u } else { 1.0 - u };
    let k = (ctx.params.f("intensity") / 100.0).clamp(0.0, 1.0);
    let amp = k * e * e * b.img.width.min(b.img.height) as f64 * 0.12;
    let t = ctx.time;
    let mut img = xform(&b.img, wobble(t, 30.0, 1, ctx.seed) * amp, wobble(t, 30.0, 2, ctx.seed) * amp, wobble(t, 30.0, 3, ctx.seed) * k * e * 6.0, 1.0 + 0.2 * k * e);
    let length = amp * 1.2;
    if length > 0.5 {
        img = directional_blur(&img, 90.0, length);
    }
    let a = (1.0 - smooth((e - 0.55) / 0.45)) as f32;
    img.data.par_iter_mut().for_each(|px| *px = scale_px(*px, a));
    keep(b, img)
}

fn flash_transition(ctx: &EffectCtx, b: Buf) -> Buf {
    let Some((u, out)) = transition_progress(ctx) else { return b };
    let k = (ctx.params.f("intensity") / 100.0).max(0.0);
    let peak = (u * PI).sin().powi(2);
    let alpha = (if out { 1.0 - smooth((u - 0.45) / 0.4) } else { smooth((u - 0.15) / 0.4) }) as f32;
    let mut img = b.img.clone();
    img.data.par_iter_mut().for_each(|px| *px = scale_px(*px, alpha));
    // The flash is light on the shape of the layer; it peaks while the layer swaps.
    map_xy(&mut img, |_, _, mut px| {
        let a = px[3].max(0.0);
        for c in 0..3 {
            px[c] += (k * peak) as f32 * a.max(0.35 * alpha.max(0.2)) * (px[3] > 0.0) as u8 as f32;
        }
        px
    });
    keep(b, img)
}

// ---------------------------------------------------------------- registry

pub fn specs() -> Vec<EffectSpec> {
    let dur = |d: f64, lo: f64, hi: f64| s("duration", "Duration (sec)", d, lo, hi, 2);
    let intensity = |d: f64, hi: f64| s("intensity", "Intensity (%)", d, 0.0, hi, 0);
    let dir = || p("direction", "Direction", Value::Enum(0), popup(&["In (layer arrives)", "Out (layer leaves)"]));
    let _ = ParamUi::Checkbox;
    vec![
        // 1. Camera & Motion
        spec("ec.lc.impactshake", "Impact Shake", CAM, vec![intensity(65.0, 100.0), s("speed", "Speed", 18.0, 1.0, 40.0, 0), dur(0.3, 0.05, 2.0), start()], impact_shake),
        spec("ec.lc.chaosshake", "Chaos Shake", CAM, vec![intensity(80.0, 100.0), s("zoom", "Zoom (%)", 108.0, 100.0, 150.0, 0), s("randomness", "Randomness (%)", 70.0, 0.0, 100.0, 0)], chaos_shake),
        spec("ec.lc.smoothdrift", "Smooth Drift", CAM, vec![s("speed", "Speed (%)", 35.0, 0.0, 100.0, 0), s("distance", "Distance (px)", 120.0, 0.0, 1000.0, 0), s("zoom", "Zoom (%)", 103.0, 100.0, 150.0, 0)], smooth_drift),
        spec("ec.lc.zoompunch", "Zoom Punch", CAM, vec![s("zoom", "Zoom (%)", 125.0, 100.0, 200.0, 0), dur(0.35, 0.05, 2.0), s("blur", "Blur (%)", 70.0, 0.0, 100.0, 0), start()], zoom_punch),
        spec("ec.lc.whipcam", "Whip Cam", CAM, vec![s("speed", "Speed (%)", 90.0, 0.0, 100.0, 0), s("distance", "Distance (px)", 600.0, 0.0, 2000.0, 0), dur(0.4, 0.05, 2.0), start()], whip_cam),
        spec("ec.lc.spinimpact", "Spin Impact", CAM, vec![s("angle", "Angle (deg)", 25.0, 0.0, 180.0, 0), s("speed", "Speed (%)", 75.0, 0.0, 100.0, 0), dur(0.4, 0.05, 2.0), start()], spin_impact),
        // 2. Glitch & Distortion
        spec("ec.lc.rgbrift", "RGB Rift", GLITCH, vec![s("split", "Split (px)", 18.0, 0.0, 100.0, 0), s("flicker", "Flicker (%)", 25.0, 0.0, 100.0, 0)], rgb_rift),
        spec("ec.lc.digitalcollapse", "Digital Collapse", GLITCH, vec![intensity(70.0, 100.0), s("blockSize", "Block Size (px)", 22.0, 1.0, 200.0, 0)], digital_collapse),
        spec("ec.lc.vhsbreakdown", "VHS Breakdown", GLITCH, vec![s("noise", "Noise (%)", 28.0, 0.0, 100.0, 0), s("distortion", "Distortion (%)", 35.0, 0.0, 100.0, 0)], vhs_breakdown),
        spec("ec.lc.pixelmelt", "Pixel Melt", GLITCH, vec![s("size", "Size (px)", 12.0, 1.0, 100.0, 0), s("stretch", "Stretch (%)", 65.0, 0.0, 100.0, 0)], pixel_melt),
        spec("ec.lc.glitchsurge", "Glitch Surge", GLITCH, vec![intensity(80.0, 100.0), s("zoom", "Zoom (%)", 115.0, 100.0, 200.0, 0), dur(0.3, 0.05, 2.0), start()], glitch_surge),
        spec("ec.lc.signalbreak", "Signal Break", GLITCH, vec![intensity(60.0, 100.0), s("speed", "Speed (%)", 70.0, 0.0, 100.0, 0)], signal_break),
        // 3. Light & Glow
        spec("ec.lc.flashimpact", "Flash Impact", LIGHT, vec![intensity(100.0, 200.0), s("frames", "Duration (frames)", 3.0, 1.0, 30.0, 0), start()], flash_impact),
        spec("ec.lc.neonaura", "Neon Aura", LIGHT, vec![s("glow", "Glow (%)", 75.0, 0.0, 200.0, 0), s("radius", "Radius (px)", 35.0, 0.0, 200.0, 0), p("color", "Color", col(0.35, 0.8, 1.0), ParamUi::Color)], neon_aura),
        spec("ec.lc.lensburst", "Lens Burst", LIGHT, vec![intensity(60.0, 100.0), s("length", "Length (%)", 70.0, 0.0, 100.0, 0)], lens_burst),
        spec("ec.lc.edgeglow", "Edge Glow", LIGHT, vec![intensity(60.0, 200.0), s("radius", "Radius (px)", 20.0, 0.0, 100.0, 0), p("color", "Color", col(0.45, 0.85, 1.0), ParamUi::Color)], edge_glow),
        spec("ec.lc.filmburn", "Film Burn", LIGHT, vec![intensity(60.0, 100.0), s("spread", "Spread (%)", 50.0, 0.0, 100.0, 0)], film_burn),
        spec("ec.lc.lightsweep", "Light Sweep", LIGHT, vec![intensity(65.0, 100.0), s("width", "Width (px)", 80.0, 5.0, 500.0, 0)], light_sweep),
        // 4. Speed & Time
        spec("ec.lc.velocityrush", "Velocity Rush", SPEED, vec![s("startSpeed", "Start Speed (x)", 0.35, 0.1, 4.0, 2), s("peakSpeed", "Peak Speed (x)", 3.0, 0.25, 10.0, 2), s("blur", "Blur (%)", 65.0, 0.0, 100.0, 0), s("rampTime", "Ramp Time (sec)", 1.5, 0.1, 10.0, 2), start()], velocity_rush),
        spec("ec.lc.timeecho", "Time Echo", SPEED, vec![s("layers", "Layers", 5.0, 1.0, 20.0, 0), s("opacity", "Opacity (%)", 45.0, 0.0, 100.0, 0)], time_echo),
        spec("ec.lc.hyperdrive", "Hyper Drive", SPEED, vec![intensity(55.0, 100.0), dur(0.25, 0.05, 2.0), start()], hyper_drive),
        spec("ec.lc.freezepop", "Freeze Pop", SPEED, vec![dur(0.4, 0.05, 5.0), s("zoom", "Zoom (%)", 108.0, 100.0, 150.0, 0), s("sharpen", "Sharpen (%)", 25.0, 0.0, 100.0, 0), start()], freeze_pop),
        spec("ec.lc.motiontrails", "Motion Trails", SPEED, vec![s("length", "Length (frames)", 5.0, 1.0, 30.0, 0), s("opacity", "Opacity (%)", 45.0, 0.0, 100.0, 0)], motion_trails),
        // 5. Text & Typography
        spec("ec.lc.kineticpunch", "Kinetic Punch", TYPO, vec![s("peak", "Peak Size (%)", 115.0, 100.0, 200.0, 0), dur(0.3, 0.05, 3.0), start()], kinetic_punch),
        spec("ec.lc.wordspotlight", "Word Spotlight", TYPO, vec![s("scale", "Scale (%)", 115.0, 100.0, 150.0, 0), p("color", "Highlight Color", col(1.0, 0.85, 0.25), ParamUi::Color), s("wordTime", "Word Time (sec)", 0.4, 0.05, 5.0, 2)], word_spotlight),
        spec("ec.lc.holotype", "Holo Type", TYPO, vec![s("glow", "Glow (%)", 60.0, 0.0, 200.0, 0), s("split", "Color Split (px)", 4.0, 0.0, 30.0, 1)], holo_type),
        spec("ec.lc.lightreveal", "Light Reveal", TYPO, vec![dur(0.5, 0.05, 3.0), s("glow", "Glow (%)", 45.0, 0.0, 100.0, 0), start()], light_reveal),
        // 6. Color & Image
        spec("ec.lc.colorsurge", "Color Surge", COLOR, vec![s("saturation", "Saturation (%)", 150.0, 0.0, 300.0, 0), s("contrast", "Contrast", 20.0, -100.0, 100.0, 0)], color_surge),
        spec("ec.lc.cinemafocus", "Cinema Focus", COLOR, vec![s("vignette", "Vignette (%)", 40.0, 0.0, 100.0, 0), s("grain", "Grain (%)", 12.0, 0.0, 100.0, 0)], cinema_focus),
        spec("ec.lc.cleansharpen", "Clean Sharpen", COLOR, vec![intensity(35.0, 100.0), s("radius", "Radius (px)", 1.5, 0.1, 10.0, 1)], clean_sharpen),
        spec("ec.lc.fisheyepro", "Fisheye Pro", COLOR, vec![s("strength", "Strength (%)", 35.0, 0.0, 100.0, 0), s("scale", "Scale (%)", 100.0, 50.0, 200.0, 0)], fisheye_pro),
        spec("ec.lc.cinematicblur", "Cinematic Blur", COLOR, vec![intensity(30.0, 100.0), s("radius", "Radius (px)", 20.0, 0.0, 200.0, 0)], cinematic_blur),
        // 7. Beat & Transition
        spec("ec.lc.rgbpulse", "RGB Pulse", BEAT, vec![intensity(60.0, 100.0), bpm(120.0)], rgb_pulse),
        spec("ec.lc.beatbounce", "Beat Bounce", BEAT, vec![s("scale", "Scale (%)", 108.0, 100.0, 150.0, 0), s("sensitivity", "Sensitivity (%)", 50.0, 0.0, 100.0, 0), bpm(120.0)], beat_bounce),
        spec("ec.lc.shaketransition", "Shake Transition", BEAT, vec![intensity(65.0, 100.0), dur(0.4, 0.05, 2.0), dir(), start()], shake_transition),
        spec("ec.lc.flashtransition", "Flash Transition", BEAT, vec![intensity(100.0, 200.0), dur(0.5, 0.1, 3.0), dir(), start()], flash_transition),
    ]
}
