//! Help menu: only the in-app tutorials remain (AE Cut has no online links).

use super::{CommandSpec, always};
use crate::{cmd};

pub fn specs() -> Vec<CommandSpec> {
    vec![cmd!("help.inAppTutorials", "In-App Tutorials...", ["Help"], None, "{} → the Home screen's Learn tab", always, |s, p| super::frontend(
        s,
        "help.inAppTutorials",
        p
    ))]
}
