//! First launch on Windows: AE Cut installs itself as a real program.
//!
//! The first time the downloaded program runs it copies itself (and its `fonts` folder) to
//! `%LOCALAPPDATA%\Programs\AE Cut`, adds a Start menu and a Desktop shortcut, makes `.lcproj`
//! and `.lcpreset` files open with it, and registers an entry under Settings ▸ Apps so it can be
//! uninstalled. All of it is per user (no administrator rights) and runs in the background while
//! the program starts. Set `LIROYC_NO_INSTALL=1` to skip it.

use std::os::windows::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::Command;

const NO_WINDOW: u32 = 0x0800_0000;
const NAME: &str = "AE Cut";

/// Start the one-time installation on a background thread (does nothing when already installed).
pub fn first_run() {
    if std::env::var_os("LIROYC_NO_INSTALL").is_some() {
        return;
    }
    std::thread::spawn(|| {
        let _ = install_once();
    });
}

fn install_once() -> std::io::Result<()> {
    let local = PathBuf::from(std::env::var_os("LOCALAPPDATA").ok_or_else(|| std::io::Error::other("no LOCALAPPDATA"))?);
    let dir = local.join("Programs").join(NAME);
    let exe = std::env::current_exe()?;
    let marker = local.join(NAME).join("installed");
    // Already running from the installed copy, or installed on an earlier launch: nothing to do.
    // Installed by "AE Cut Setup.exe": the installer already made shortcuts and the uninstaller.
    let by_setup = exe.parent().map(|p| p.join("setup.marker").exists()).unwrap_or(false);
    if by_setup || exe.starts_with(&dir) || marker.exists() {
        return Ok(());
    }
    std::fs::create_dir_all(&dir)?;
    let target = dir.join(format!("{NAME}.exe"));
    std::fs::copy(&exe, &target)?;
    if let Some(src) = exe.parent().map(|p| p.join("fonts")).filter(|p| p.is_dir()) {
        copy_dir(&src, &dir.join("fonts"))?;
    }
    shortcuts(&target, &dir);
    register(&target, &dir);
    if let Some(parent) = marker.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::write(&marker, env!("CARGO_PKG_VERSION"))
}

fn copy_dir(from: &Path, to: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for entry in std::fs::read_dir(from)?.flatten() {
        let (src, dst) = (entry.path(), to.join(entry.file_name()));
        if src.is_dir() {
            copy_dir(&src, &dst)?;
        } else {
            std::fs::copy(&src, &dst)?;
        }
    }
    Ok(())
}

fn quiet(program: &str, args: &[&str]) {
    let _ = Command::new(program).args(args).creation_flags(NO_WINDOW).status();
}

/// A Desktop and a Start menu shortcut (through the Windows scripting host).
fn shortcuts(target: &Path, dir: &Path) {
    let script = format!(
        "$ws = New-Object -ComObject WScript.Shell; \
         foreach ($p in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs'))) {{ \
           $s = $ws.CreateShortcut((Join-Path $p '{NAME}.lnk')); \
           $s.TargetPath = '{t}'; $s.WorkingDirectory = '{d}'; $s.IconLocation = '{t}'; $s.Save() }}",
        t = target.display(),
        d = dir.display(),
    );
    quiet("powershell", &["-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", &script]);
}

fn reg(key: &str, name: Option<&str>, value: &str) {
    match name {
        Some(n) => quiet("reg", &["add", key, "/v", n, "/t", "REG_SZ", "/d", value, "/f"]),
        None => quiet("reg", &["add", key, "/ve", "/t", "REG_SZ", "/d", value, "/f"]),
    }
}

/// File types and the Settings ▸ Apps entry (current user only).
fn register(target: &Path, dir: &Path) {
    let exe = target.display().to_string();
    let classes = r"HKCU\Software\Classes";
    for (ext, class, label) in [("lcproj", "AECut.Project", "AE Cut project"), ("lcpreset", "AECut.Preset", "AE Cut preset"), ("lctemplate", "AECut.Template", "AE Cut template")] {
        reg(&format!(r"{classes}\.{ext}"), None, class);
        reg(&format!(r"{classes}\{class}"), None, label);
        reg(&format!(r"{classes}\{class}\DefaultIcon"), None, &format!("{exe},0"));
        reg(&format!(r"{classes}\{class}\shell\open\command"), None, &format!("\"{exe}\" \"%1\""));
    }
    let uninstall = format!(r"HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\{NAME}");
    reg(&uninstall, Some("DisplayName"), NAME);
    reg(&uninstall, Some("DisplayVersion"), env!("CARGO_PKG_VERSION"));
    reg(&uninstall, Some("Publisher"), "Liroy C");
    reg(&uninstall, Some("DisplayIcon"), &exe);
    reg(&uninstall, Some("InstallLocation"), &dir.display().to_string());
    let cleanup = format!(
        "cmd /c del \"%USERPROFILE%\\Desktop\\{NAME}.lnk\" & del \"%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\{NAME}.lnk\" & rmdir /s /q \"{}\" & reg delete \"{uninstall}\" /f",
        dir.display()
    );
    reg(&uninstall, Some("UninstallString"), &cleanup);
}
