//! Home ▸ "Migrate from AE" (מעבר מ-AE): turns After Effects presets (`.ffx`) into AE Cut
//! presets (`.lcpreset`) and After Effects projects (`.aep`) into AE Cut projects
//! (`.lcproj`). The conversion itself is `effectcraft_engine::ae_migrate`; the buttons run the
//! `ae.convertPreset` / `ae.convertProject` commands, which ask for the file.
//!
//! Automation ids: `home.migrate.ffx`, `home.migrate.aep`.

use egui::{Align2, Color32, Rect, pos2, vec2};
use serde_json::json;

use crate::i18n::tr;
use crate::theme::Tokens;
use crate::{EffectcraftApp, widgets};

const CARDS: [(&str, &str, &str, &str, &str); 2] = [
    (
        "Convert FFX presets to LCPRESET",
        "Pick an After Effects animation preset (.ffx). Every effect in it that AE Cut has an equivalent for is written to a new .lcpreset file, ready for Animation > Apply Animation Preset. Effects are added with their default settings.",
        "Choose .ffx file…",
        "ae.convertPreset",
        "ffx",
    ),
    (
        "Convert AEP projects to LCPROJ",
        "Pick an After Effects project (.aep). A new .lcproj is created with the same compositions and the same layer names and order, ready to open and keep working on. Footage, keyframes and effects are not carried over.",
        "Choose .aep file…",
        "ae.convertProject",
        "aep",
    ),
];

pub fn home_tab(app: &mut EffectcraftApp, ui: &mut egui::Ui, area: Rect) {
    let t = app.tokens;
    let ctx = ui.ctx().clone();
    let p = ui.painter().with_clip_rect(area);
    let (x, mut y, w) = (area.min.x, area.min.y, area.width());
    p.text(pos2(x, y + 6.0), Align2::LEFT_CENTER, tr("Migrate from AE"), Tokens::semibold(16.0), Color32::WHITE);
    p.text(pos2(x, y + 28.0), Align2::LEFT_CENTER, tr("Bring your presets and projects with you."), Tokens::ui(11.5), t.text_faint);
    y += 52.0;
    for (title, desc, button, command, tag) in CARDS {
        let card_h = 188.0;
        let r = Rect::from_min_size(pos2(x, y), vec2(w, card_h - 14.0));
        if r.min.y > area.max.y {
            break;
        }
        p.rect_filled(r, 12.0, t.panel_bg);
        crate::theme::brand_gradient_alpha(&p, Rect::from_min_size(r.min, vec2(r.width(), 3.0)), 220);
        p.text(pos2(r.min.x + 20.0, r.min.y + 30.0), Align2::LEFT_CENTER, tr(title), Tokens::semibold(15.0), Color32::WHITE);
        let g = p.layout(tr(desc).to_string(), Tokens::ui(12.0), t.text_dim, (r.width() - 40.0).max(120.0));
        p.galley(pos2(r.min.x + 20.0, r.min.y + 52.0), g, t.text_dim);
        let br = Rect::from_min_size(pos2(r.min.x + 20.0, r.max.y - 46.0), vec2(200.0, 32.0));
        let clicked = widgets::text_button(ui, br, tr(button), true, &t, egui::Id::new(("migrate", command))).clicked();
        app.auto.add(&format!("home.migrate.{tag}"), br, button);
        if clicked && let Err(e) = crate::menus::invoke(app, &ctx, command, json!({})) {
            app.ui.status = e;
        }
        y += card_h;
    }
    p.text(pos2(x, y + 4.0), Align2::LEFT_CENTER, tr("The new file is saved next to the original."), Tokens::ui(11.0), t.text_faint);
}
