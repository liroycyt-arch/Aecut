﻿; Hebrew translation for the AE Cut installer (Inno Setup). Messages not listed here fall back to English.
[LangOptions]
LanguageName=<05E2><05D1><05E8><05D9><05EA>
LanguageID=$040D
LanguageCodePage=1255
RightToLeft=yes
DialogFontName=Segoe UI
DialogFontSize=9
WelcomeFontName=Segoe UI
WelcomeFontSize=12

[Messages]
SetupAppTitle=התקנה
SetupWindowTitle=התקנת %1
UninstallAppTitle=הסרת התקנה
UninstallAppFullTitle=הסרת ההתקנה של %1
ButtonBack=< &הקודם
ButtonNext=&הבא >
ButtonInstall=&התקנה
ButtonOK=אישור
ButtonCancel=ביטול
ButtonYes=&כן
ButtonNo=&לא
ButtonFinish=&סיום
ButtonBrowse=&עיון...
ExitSetupTitle=יציאה מההתקנה
ExitSetupMessage=ההתקנה לא הושלמה. אם תצא עכשיו, התוכנה לא תותקן.%n%nאפשר להפעיל את ההתקנה שוב בכל זמן.%n%nלצאת מההתקנה?
WelcomeLabel1=ברוכים הבאים להתקנת [name]
WelcomeLabel2=האשף יתקין את [name/ver] במחשב שלך.%n%nמומלץ לסגור תוכנות אחרות לפני שממשיכים.
WizardSelectDir=בחירת תיקיית ההתקנה
SelectDirDesc=איפה להתקין את [name]?
SelectDirLabel3=האשף יתקין את [name] בתיקייה הבאה.
SelectDirBrowseLabel=לחץ על "הבא" כדי להמשיך. כדי לבחור תיקייה אחרת, לחץ על "עיון".
WizardSelectTasks=משימות נוספות
SelectTasksDesc=אילו משימות נוספות לבצע?
SelectTasksLabel2=בחר את המשימות הנוספות ולחץ על "הבא".
WizardReady=מוכן להתקנה
ReadyLabel1=האשף מוכן להתקין את [name] במחשב שלך.
ReadyLabel2a=לחץ על "התקנה" כדי להתחיל, או על "הקודם" כדי לשנות הגדרות.
WizardInstalling=מתקין
InstallingLabel=אנא המתן בזמן ש-[name] מותקן במחשב שלך.
FinishedHeadingLabel=ההתקנה של [name] הושלמה
FinishedLabelNoIcons=[name] הותקן במחשב שלך.
FinishedLabel=[name] הותקן במחשב שלך. אפשר להפעיל אותו דרך הקיצורים שנוצרו.
ClickFinish=לחץ על "סיום" כדי לצאת מההתקנה.
StatusExtractFiles=מחלץ קבצים...
StatusCreateIcons=יוצר קיצורי דרך...
StatusCreateRegistryEntries=יוצר רשומות במערכת...
ConfirmUninstall=האם אתה בטוח שברצונך להסיר את %1 ואת כל רכיביו?
UninstalledAll=%1 הוסר מהמחשב בהצלחה.
ErrorTitle=שגיאה
[CustomMessages]
hebrew.TaskDesktop=צור קיצור דרך בשולחן העבודה
hebrew.TaskAssoc=שייך קבצי פרויקט (.lcproj) ל-AE Cut
hebrew.LaunchApp=הפעל את AE Cut עכשיו
